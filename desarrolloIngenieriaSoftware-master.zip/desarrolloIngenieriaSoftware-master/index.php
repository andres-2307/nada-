<?php
        session_start();
?>




<script> 
window.location.replace('paginas/principal.php'); 
</script>
