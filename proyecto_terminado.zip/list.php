<?php 
include ("php/header.php");

?>
<div class="container-fluid">
<div id="listarTodos"></div>
</div>

<?php 
include ("php/footer.php");

?>
<script>window.onload = listar();</script>