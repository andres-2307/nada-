
    
<?php 
include ("php/header.php");

?>

<div class="jumbotron jumbotron-fluid"style="background-color:  #0d61b738;">
  <div class="container">
    <h1 class="display-3">API </h1>
    <h2 class=" display-5">Mesa de Trabajo Universitario</h2>
  </div>
</div>
        
   
    <?php  
include ("php/footer.php");

?>
  </body>
</html> 